# Unified Mentor: Supply Chain Profitability Analysis

## Project title
Customer, Product, and Profitability Performance Analysis in Supply Chain Operations

## Files
- `APL_Logistics.csv` — supplied dataset
- `analysis.py` — data preparation, KPI tables, data quality report, and charts
- `app.py` — interactive Streamlit dashboard
- `requirements.txt` — required Python libraries
- `outputs/` — generated CSV summaries and charts (created after running analysis.py)

## 1. Setup
Install Python 3.10 or newer. Open a terminal in this folder and run:

```bash
python -m pip install -r requirements.txt
```

## 2. Run the analysis
```bash
python analysis.py
```
Check `outputs/data_quality_report.csv` and the generated KPI tables before writing conclusions.

## 3. Run the dashboard
```bash
streamlit run app.py
```

## Financial metric definitions
- Gross Sales: sum of `Sales`.
- Net Sales: sum of `Order Item Total` (post-discount item total), where available.
- Profit: sum of `Order Profit Per Order`, falling back to `Benefit per order` if needed.
- Profit margin: total profit divided by total net sales, multiplied by 100.

These are dataset-based proxies. Confirm the dataset's business definitions and currency before presenting financial figures as official results. The file contains customer names and street-level information; do not publish those personal fields in a public repository or dashboard. Exclude or mask personal data before sharing publicly.

## Deployment
Push the code to a GitHub repository and deploy `app.py` using Streamlit Community Cloud. Keep the dataset private unless you have permission to publish it. If the platform requires a public repository, use a version of the dataset with personal fields removed.

## Research paper reminder
Only report findings after running the analysis. Do not invent results. Include the data quality checks, metric definitions, limitations, insights, and recommendations.
