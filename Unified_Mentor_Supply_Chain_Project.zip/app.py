"""
Streamlit dashboard for Unified Mentor Supply Chain Profitability project.
Run: streamlit run app.py
"""
from pathlib import Path
import pandas as pd
import streamlit as st
import plotly.express as px

st.set_page_config(page_title="Supply Chain Profitability", page_icon="📊", layout="wide")
BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "APL_Logistics.csv"

@st.cache_data
def load_data():
    df = pd.read_csv(DATA_PATH, encoding="latin1")
    df.columns = df.columns.str.strip()
    for col in ["Sales", "Order Item Total", "Order Profit Per Order", "Benefit per order",
                "Order Item Discount Rate", "Order Item Discount", "Order Item Quantity"]:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")
    df = df.drop_duplicates().copy()
    df["Profit"] = df["Order Profit Per Order"] if "Order Profit Per Order" in df else df["Benefit per order"]
    df["Net Sales"] = df["Order Item Total"] if "Order Item Total" in df else df["Sales"]
    df["Profit Margin (%)"] = df["Profit"].div(df["Net Sales"].where(df["Net Sales"] != 0)).mul(100)
    return df

st.title("Customer, Product & Profitability Performance")
st.caption("Unified Mentor | Supply Chain Operations Analytics")

if not DATA_PATH.exists():
    st.error("APL_Logistics.csv is missing. Place the CSV file in the same folder as app.py.")
    st.stop()

df = load_data()

with st.sidebar:
    st.header("Dashboard Filters")
    segments = sorted(df["Customer Segment"].dropna().unique().tolist()) if "Customer Segment" in df else []
    selected_segments = st.multiselect("Customer segment", segments, default=segments)
    categories = sorted(df["Category Name"].dropna().unique().tolist()) if "Category Name" in df else []
    selected_categories = st.multiselect("Product category", categories, default=categories)
    markets = sorted(df["Market"].dropna().unique().tolist()) if "Market" in df else []
    selected_markets = st.multiselect("Market", markets, default=markets)
    max_discount = float(df["Order Item Discount Rate"].max()) if "Order Item Discount Rate" in df else 1.0
    discount_limit = st.slider("Maximum discount rate", 0.0, max(0.01, max_discount), max(0.0, max_discount), 0.01)

filtered = df.copy()
if selected_segments and "Customer Segment" in filtered:
    filtered = filtered[filtered["Customer Segment"].isin(selected_segments)]
if selected_categories and "Category Name" in filtered:
    filtered = filtered[filtered["Category Name"].isin(selected_categories)]
if selected_markets and "Market" in filtered:
    filtered = filtered[filtered["Market"].isin(selected_markets)]
if "Order Item Discount Rate" in filtered:
    filtered = filtered[filtered["Order Item Discount Rate"].fillna(0) <= discount_limit]

net_sales = filtered["Net Sales"].sum()
profit = filtered["Profit"].sum()
margin = profit / net_sales * 100 if net_sales else 0
discount_avg = filtered["Order Item Discount Rate"].mean() * 100 if "Order Item Discount Rate" in filtered else 0

c1, c2, c3, c4 = st.columns(4)
c1.metric("Net Sales", f"{net_sales:,.2f}")
c2.metric("Total Profit", f"{profit:,.2f}")
c3.metric("Profit Margin", f"{margin:.2f}%")
c4.metric("Average Discount", f"{discount_avg:.2f}%")

tab1, tab2, tab3, tab4 = st.tabs(["Overview", "Customers", "Products", "Discount Analysis"])
with tab1:
    left, right = st.columns(2)
    if "Market" in filtered:
        market = filtered.groupby("Market", as_index=False).agg(Net_Sales=("Net Sales", "sum"), Profit=("Profit", "sum"))
        left.plotly_chart(px.bar(market, x="Market", y="Profit", title="Profit by Market"), use_container_width=True)
    if "Order Region" in filtered:
        region = filtered.groupby("Order Region", as_index=False)["Profit"].sum().sort_values("Profit", ascending=False)
        right.plotly_chart(px.bar(region, x="Order Region", y="Profit", title="Profit by Order Region"), use_container_width=True)
    st.subheader("Data preview")
    st.dataframe(filtered.head(100), use_container_width=True)

with tab2:
    if "Customer Id" in filtered:
        customer = filtered.groupby("Customer Id", as_index=False).agg(
            Net_Sales=("Net Sales", "sum"), Profit=("Profit", "sum"), Items=("Profit", "size")
        ).sort_values("Profit", ascending=False)
        left, right = st.columns(2)
        left.subheader("Top 10 customers by profit")
        left.dataframe(customer.head(10), use_container_width=True)
        right.subheader("Bottom 10 customers by profit")
        right.dataframe(customer.tail(10).sort_values("Profit"), use_container_width=True)
        if "Customer Segment" in filtered:
            seg = filtered.groupby("Customer Segment", as_index=False)["Profit"].sum()
            st.plotly_chart(px.pie(seg, names="Customer Segment", values="Profit", title="Profit contribution by customer segment"), use_container_width=True)

with tab3:
    if "Product Name" in filtered:
        product = filtered.groupby("Product Name", as_index=False).agg(
            Net_Sales=("Net Sales", "sum"), Profit=("Profit", "sum")
        ).sort_values("Profit", ascending=False)
        st.subheader("Top 15 products by profit")
        st.plotly_chart(px.bar(product.head(15), x="Product Name", y="Profit", title="Top products by profit"), use_container_width=True)
        st.subheader("Lowest 15 products by profit")
        st.dataframe(product.tail(15).sort_values("Profit"), use_container_width=True)
    if "Category Name" in filtered:
        category = filtered.groupby("Category Name", as_index=False).agg(Net_Sales=("Net Sales", "sum"), Profit=("Profit", "sum"))
        st.plotly_chart(px.bar(category, x="Category Name", y="Profit", title="Profit by category"), use_container_width=True)

with tab4:
    if "Order Item Discount Rate" in filtered:
        disc = filtered.copy()
        disc["Discount Band"] = pd.cut(
            disc["Order Item Discount Rate"],
            bins=[-0.001, 0.05, 0.10, 0.15, 0.20, 1.0],
            labels=["0–5%", "5–10%", "10–15%", "15–20%", "20%+"],
            include_lowest=True
        )
        summary = disc.groupby("Discount Band", observed=False, as_index=False).agg(
            Records=("Profit", "size"), Net_Sales=("Net Sales", "sum"),
            Profit=("Profit", "sum"), Average_Margin=("Profit Margin (%)", "mean")
        )
        st.plotly_chart(px.bar(summary, x="Discount Band", y="Average_Margin", title="Average margin by discount band"), use_container_width=True)
        st.dataframe(summary, use_container_width=True)
        st.info("Association between discount and margin does not prove that discounts alone caused a margin change. Validate business costs and pricing rules before making decisions.")

st.download_button(
    "Download filtered data as CSV",
    data=filtered.to_csv(index=False).encode("utf-8"),
    file_name="filtered_supply_chain_data.csv",
    mime="text/csv"
)
