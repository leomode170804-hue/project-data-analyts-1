"""
Unified Mentor Project
Customer, Product, and Profitability Performance Analysis in Supply Chain Operations

Run:
    python analysis.py
"""
from pathlib import Path
import pandas as pd
import matplotlib.pyplot as plt

BASE_DIR = Path(__file__).resolve().parent
DATA_PATH = BASE_DIR / "APL_Logistics.csv"
OUTPUT_DIR = BASE_DIR / "outputs"
OUTPUT_DIR.mkdir(exist_ok=True)

def load_data(path=DATA_PATH):
    # The supplied CSV contains accented characters, so latin1 is used.
    df = pd.read_csv(path, encoding="latin1")
    df.columns = df.columns.str.strip()

    numeric_cols = [
        "Sales", "Order Profit Per Order", "Benefit per order",
        "Order Item Discount", "Order Item Discount Rate",
        "Order Item Total", "Order Item Quantity", "Product Price",
        "Order Item Product Price", "Customer Id", "Order Customer Id"
    ]
    for col in numeric_cols:
        if col in df.columns:
            df[col] = pd.to_numeric(df[col], errors="coerce")

    # Remove exact duplicate rows only; do not delete legitimate zero-value records automatically.
    df = df.drop_duplicates().copy()

    # Prefer the order-level profit field, falling back to Benefit per order if needed.
    if "Order Profit Per Order" in df.columns:
        df["Profit"] = df["Order Profit Per Order"]
    else:
        df["Profit"] = df["Benefit per order"]

    # Sales is gross sales; Order Item Total is post-discount item value.
    # Use Order Item Total as net sales when available.
    if "Order Item Total" in df.columns:
        df["Net Sales"] = df["Order Item Total"]
    else:
        df["Net Sales"] = df["Sales"]

    df["Profit Margin (%)"] = (
        df["Profit"].div(df["Net Sales"].where(df["Net Sales"] != 0)).mul(100)
    )
    df["Customer Id"] = df.get("Customer Id", df.get("Order Customer Id"))
    return df

def save_summary_tables(df):
    # Summary tables use consistent definitions: Net Sales = post-discount item total;
    # Profit = Order Profit Per Order (or Benefit per order if unavailable).
    overall = pd.DataFrame({
        "Metric": ["Rows after exact-duplicate removal", "Gross Sales", "Net Sales", "Total Profit",
                   "Overall Profit Margin (%)", "Average Discount Rate (%)", "Late Delivery Rate (%)"],
        "Value": [
            len(df),
            df["Sales"].sum() if "Sales" in df else float("nan"),
            df["Net Sales"].sum(),
            df["Profit"].sum(),
            df["Profit"].sum() / df["Net Sales"].sum() * 100 if df["Net Sales"].sum() else float("nan"),
            df["Order Item Discount Rate"].mean() * 100 if "Order Item Discount Rate" in df else float("nan"),
            df["Late_delivery_risk"].mean() * 100 if "Late_delivery_risk" in df else float("nan")
        ]
    })
    overall.to_csv(OUTPUT_DIR / "overall_kpis.csv", index=False)

    dimensions = [
        ("Customer Id", "customer_profitability.csv"),
        ("Product Name", "product_profitability.csv"),
        ("Category Name", "category_profitability.csv"),
        ("Market", "market_profitability.csv"),
        ("Order Region", "region_profitability.csv"),
        ("Customer Segment", "segment_profitability.csv"),
    ]
    for dim, filename in dimensions:
        if dim not in df.columns:
            continue
        table = df.groupby(dim, dropna=False).agg(
            Orders_or_Items=("Profit", "size"),
            Net_Sales=("Net Sales", "sum"),
            Total_Profit=("Profit", "sum"),
            Average_Profit_Margin=("Profit Margin (%)", "mean"),
        ).reset_index()
        table["Overall_Margin_on_Aggregates_%"] = (
            table["Total_Profit"] / table["Net_Sales"].replace(0, pd.NA) * 100
        )
        table.sort_values("Total_Profit", ascending=False).to_csv(OUTPUT_DIR / filename, index=False)

    if "Order Item Discount Rate" in df.columns:
        df.assign(Discount_Band=pd.cut(
            df["Order Item Discount Rate"],
            bins=[-0.001, 0.05, 0.10, 0.15, 0.20, 1.0],
            labels=["0–5%", "5–10%", "10–15%", "15–20%", "20%+"],
            include_lowest=True
        )).groupby("Discount_Band", observed=False).agg(
            Records=("Profit", "size"),
            Net_Sales=("Net Sales", "sum"),
            Total_Profit=("Profit", "sum"),
            Average_Profit_Margin=("Profit Margin (%)", "mean")
        ).reset_index().to_csv(OUTPUT_DIR / "discount_analysis.csv", index=False)

    # A small data quality report for the project documentation.
    quality = pd.DataFrame({
        "Column": df.columns,
        "Missing_Values": [int(df[c].isna().sum()) for c in df.columns],
        "Missing_Percent": [round(df[c].isna().mean() * 100, 3) for c in df.columns],
        "Data_Type": [str(df[c].dtype) for c in df.columns],
    })
    quality.to_csv(OUTPUT_DIR / "data_quality_report.csv", index=False)

def save_charts(df):
    # Use default Matplotlib styling.
    if "Category Name" in df.columns:
        category = df.groupby("Category Name")["Profit"].sum().sort_values()
        plt.figure(figsize=(10, 7))
        category.plot(kind="barh")
        plt.title("Total Profit by Product Category")
        plt.xlabel("Total Profit")
        plt.tight_layout()
        plt.savefig(OUTPUT_DIR / "profit_by_category.png", dpi=150)
        plt.close()

    if "Market" in df.columns:
        market = df.groupby("Market")["Profit"].sum().sort_values(ascending=False)
        plt.figure(figsize=(9, 5))
        market.plot(kind="bar")
        plt.title("Total Profit by Market")
        plt.ylabel("Total Profit")
        plt.xticks(rotation=30, ha="right")
        plt.tight_layout()
        plt.savefig(OUTPUT_DIR / "profit_by_market.png", dpi=150)
        plt.close()

def main():
    if not DATA_PATH.exists():
        raise FileNotFoundError(
            "APL_Logistics.csv was not found. Put the dataset in the same folder as analysis.py."
        )
    df = load_data()
    save_summary_tables(df)
    save_charts(df)
    print(f"Analysis complete. Rows analysed: {len(df):,}")
    print(f"Outputs saved to: {OUTPUT_DIR}")
    print("Review outputs/data_quality_report.csv before interpreting results.")

if __name__ == "__main__":
    main()
